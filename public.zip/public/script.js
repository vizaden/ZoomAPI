const statusBox = document.getElementById("status");
const createBtn = document.getElementById("createBtn");
const chatBtn = document.getElementById("chatBtn");

function showStatus(message, type = "success") {
  statusBox.textContent = message;
  statusBox.className = `status ${type}`;
  statusBox.classList.remove("hidden");
}

async function createMeeting() {
  try {
    showStatus("Creating meeting...");

    const res = await fetch("/create-meeting", { method: "POST" });
    const data = await res.json();

    window.open(data.join_url, "_blank");
    showStatus("Meeting created successfully!");
  } catch (err) {
    showStatus("Failed to create meeting", "error");
  }
}

async function sendChat() {
  try {
    showStatus("Sending chat message...");

    const res = await fetch("/send-chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "Hello from Zoom API!" })
    });

    const data = await res.json();

    if (res.ok) {
      showStatus("Chat message sent!");
    } else {
      showStatus(data.details || "Chat failed", "error");
    }
  } catch (err) {
    showStatus("Chat request failed", "error");
  }
}

createBtn.addEventListener("click", createMeeting);
chatBtn.addEventListener("click", sendChat);
